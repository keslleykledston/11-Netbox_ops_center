# Manual de Integração: Módulo NetBox Ops Center (Looking Glass e IRR)

**Autor:** Manus AI
**Data:** 11 de Dezembro de 2025

## 1. Introdução ao Módulo

Este documento detalha o processo de integração do novo **Módulo NetBox Ops Center** ao seu projeto `netbox-ops-center` (referência: [https://github.com/keslleykledston/netbox-ops-center]()).

O módulo foi desenvolvido em **React** e **TypeScript**, seguindo a arquitetura do seu projeto, e adiciona duas funcionalidades essenciais para operações de rede:

1.  **Looking Glass (LG):** Consulta de rotas BGP em tempo real, utilizando a API pública do RIPEstat [1].
2.  **Gerenciador de IRR:** Ferramenta de consulta e manutenção de objetos RPSL (route, aut-num, mntner, etc.) na base de dados IRR do bgp.net.br [2].

## 2. Estrutura de Arquivos do Módulo

O módulo é composto por 5 arquivos principais que devem ser copiados para o diretório `src/modules/` do seu projeto, dentro de uma nova pasta chamada `OpsCenterModule`.

**Estrutura de Diretórios a ser Criada:**

```
src/
└── modules/
    └── OpsCenterModule/
        ├── api.ts             <-- Lógica de chamada às APIs (RIPEstat e bgp.net.br)
        ├── types.ts           <-- Definições de tipos TypeScript
        ├── LookingGlass.tsx   <-- Componente React para a funcionalidade Looking Glass
        ├── IRRManager.tsx     <-- Componente React para o Gerenciador de IRR
        ├── OpsCenterModule.tsx<-- Componente principal que agrega LG e IRR Manager
        └── index.ts           <-- Arquivo de exportação do módulo
```

### 2.1. Arquivos Fornecidos

Os seguintes arquivos foram gerados e devem ser copiados para a estrutura acima:

| Arquivo | Descrição |
| :--- | :--- |
| `ops_center_module_types.ts` | Renomear para `src/modules/OpsCenterModule/types.ts` |
| `ops_center_module_api.ts` | Renomear para `src/modules/OpsCenterModule/api.ts` |
| `LookingGlass.tsx` | Copiar para `src/modules/OpsCenterModule/LookingGlass.tsx` |
| `IRRManager.tsx` | Copiar para `src/modules/OpsCenterModule/IRRManager.tsx` |
| `OpsCenterModule.tsx` | Copiar para `src/modules/OpsCenterModule/OpsCenterModule.tsx` |
| `module_index.ts` | Renomear para `src/modules/OpsCenterModule/index.ts` |

## 3. Passo a Passo da Integração

A integração requer a criação de um arquivo de rotas e a modificação do componente de navegação principal do seu projeto.

### Passo 3.1: Criar o Arquivo de Configuração de Rotas

Crie um novo arquivo na raiz do seu projeto (ou no diretório de rotas, se houver) chamado `opsCenterRoutes.tsx` e adicione o conteúdo do arquivo `route_config.tsx` fornecido.

**Conteúdo de `opsCenterRoutes.tsx`:**

```tsx
// Conteúdo do arquivo route_config.tsx
import React, { lazy } from 'react';
import { RouteObject } from 'react-router-dom'; // Assumindo react-router-dom

// Importação do componente principal do novo módulo
// O caminho deve ser ajustado conforme a estrutura final do projeto
const OpsCenterModule = lazy(() => import('./src/modules/OpsCenterModule/OpsCenterModule'));

export const opsCenterRoutes: RouteObject[] = [
  {
    path: '/ops-center',
    element: <OpsCenterModule />,
    handle: {
      title: 'NetBox Ops Center',
      crumb: () => 'Ops Center',
    },
  },
];
```

### Passo 3.2: Integrar as Novas Rotas

Localize o arquivo principal de configuração de rotas do seu projeto (geralmente `src/App.tsx` ou um arquivo de roteador dedicado) e importe e adicione as novas rotas.

**Exemplo de Modificação no Arquivo Principal de Rotas:**

```tsx
// Exemplo de arquivo principal de rotas (App.tsx ou router.tsx)
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
// ... outras importações
import { opsCenterRoutes } from './opsCenterRoutes'; // Importar o novo arquivo

const router = createBrowserRouter([
  // ... outras rotas existentes
  ...opsCenterRoutes, // <-- ADICIONAR ESTA LINHA
  // ...
]);

const App = () => {
  return <RouterProvider router={router} />;
};
```

### Passo 3.3: Adicionar o Link de Navegação

Localize o componente de navegação principal do seu projeto (ex: `src/components/Sidebar.tsx` ou `src/components/Header.tsx`) e adicione o link para o novo módulo.

**Conteúdo do Componente de Link (`OpsCenterNavLink`):**

```tsx
// Conteúdo do arquivo navigation_link.tsx
import { Link } from 'react-router-dom'; // Assumindo react-router-dom
import { Wrench } from 'lucide-react'; // Ícone de ferramenta

// Componente de Link de Navegação para o Módulo Ops Center
export const OpsCenterNavLink: React.FC = () => {
  return (
    <Link
      to="/ops-center"
      className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-900 transition-all hover:text-primary dark:text-gray-400 dark:hover:text-gray-50"
    >
      <Wrench className="h-4 w-4" />
      NetBox Ops Center
    </Link>
  );
};
```

**Exemplo de Modificação no Componente de Navegação:**

```tsx
// Exemplo de arquivo principal de Sidebar (Sidebar.tsx)
import { OpsCenterNavLink } from './OpsCenterNavLink'; // Ajustar o caminho de importação

const Sidebar = () => {
  return (
    <nav className="flex flex-col gap-1">
      {/* ... outros links de navegação */}
      <OpsCenterNavLink /> {/* <-- ADICIONAR ESTA LINHA */}
      {/* ... */}
    </nav>
  );
};
```

## 4. Funcionalidades e Uso do Módulo

O módulo será acessível na rota `/ops-center` e apresenta duas abas:

### 4.1. Looking Glass

*   **Função:** Consulta rotas BGP para um prefixo ou endereço IP.
*   **API Utilizada:** RIPEstat Looking Glass API [1].
*   **Uso:** Insira um prefixo (ex: `192.0.2.0/24`) ou IP (ex: `8.8.8.8`) e clique em **Consultar Looking Glass**. Os resultados serão agrupados por RRC (Route Collector) e detalharão o AS Path, ASN de origem e Next Hop.

### 4.2. Gerenciador de IRR

*   **Função:** Consulta e submissão de objetos RPSL.
*   **APIs Utilizadas:** bgp.net.br GraphQL (Consulta) e REST (`/v1/submit`) (Submissão) [2].
*   **Consulta:** Utilize a aba **Consultar Objetos** para buscar por ASN, prefixo ou maintainer.
*   **Submissão:** Utilize a aba **Submeter Objeto** para criar ou atualizar objetos RPSL. O objeto deve ser inserido em formato texto (ex: `route: 192.0.2.0/24\norigin: AS65000\n...`). A submissão pode exigir credenciais (e-mail e senha) dependendo da política do bgp.net.br.

## 5. Referências

| Ref | Descrição | URL |
| :--- | :--- | :--- |
| [1] | RIPEstat Data API - Looking Glass | [https://stat.ripe.net/docs/data-api/api-endpoints/looking-glass]() |
| [2] | bgp.net.br - FAQ (menciona API de submissão) | [https://bgp.net.br/faq.html]() |
| [3] | bgp.net.br - GraphQL Interface | [https://bgp.net.br/graphql/]() |
| [4] | Projeto netbox-ops-center | [https://github.com/keslleykledston/netbox-ops-center]() |
