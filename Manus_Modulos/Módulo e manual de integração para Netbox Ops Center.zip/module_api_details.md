# Detalhes da API e Estrutura de Dados para o Módulo Ops Center

Este documento detalha os endpoints de API e a estrutura de dados esperada para as funcionalidades de Looking Glass (LG) e Gerenciamento de IRR, que serão implementadas como componentes React/TypeScript no projeto `netbox-ops-center`.

## 1. Looking Glass (LG) - Consulta de Rotas BGP

Para a funcionalidade de Looking Glass, utilizaremos a API pública e bem documentada do **RIPEstat**.

### 1.1. Endpoint de Consulta

| Tipo | URL Base | Parâmetros Chave |
| :--- | :--- | :--- |
| **REST GET** | `https://stat.ripe.net/data/looking-glass/data.json` | `resource` (Prefixos IPv4/IPv6 ou Endereços IP) |

### 1.2. Estrutura de Dados de Resposta (JSON)

A resposta da API será processada para extrair informações chave de roteamento.

```typescript
interface LookingGlassResult {
  // ... outros campos de metadados
  data: {
    rrcs: RRCCollector[];
    latest_time: string;
  };
}

interface RRCCollector {
  rrc_id: string;
  location: string;
  peers: BGPPeer[];
}

interface BGPPeer {
  prefix: string;
  as_path: string; // Ex: "AS64512 AS65534 AS12345"
  next_hop: string;
  asn_origin: string; // O ASN de origem do prefixo
  last_updated: string;
  peer: string; // IP do peer BGP
  // ... outros campos
}
```

## 2. Gerenciamento de IRR - Consulta e Manutenção

Para o Gerenciamento de IRR, utilizaremos a API do **bgp.net.br**, que oferece uma interface GraphQL para consultas e uma API REST para submissão/manutenção.

### 2.1. Consulta de Objetos IRR (GraphQL)

A consulta será feita via POST para o endpoint GraphQL.

| Tipo | URL Base | Método |
| :--- | :--- | :--- |
| **GraphQL** | `https://bgp.net.br/graphql/` | `POST` |

**Exemplo de Query (Consulta de um objeto `route` ou `route6`):**

```graphql
query GetRPSLObject($search: String!) {
  rpslObjects(
    textSearch: $search,
    sources: ["BGPBR"] // Filtrar pela fonte BGP.net.br
  ) {
    object {
      // Campos comuns a todos os objetos RPSL
      objectClass
      primaryKey
      source
      // Campos específicos de objetos route/route6
      ... on RPSLRoute {
        route
        origin
        mntBy
        descr
      }
      ... on RPSLRoute6 {
        route6
        origin
        mntBy
        descr
      }
      // ... outros objetos RPSL (aut-num, as-set, etc.)
    }
  }
}
```

### 2.2. Manutenção/Atualização de Objetos IRR (REST)

A manutenção (criação, atualização, exclusão) de objetos IRR é feita através da submissão de um objeto RPSL formatado.

| Tipo | URL Base | Método |
| :--- | :--- | :--- |
| **REST** | `https://bgp.net.br/v1/submit` | `POST` |

**Corpo da Requisição (Exemplo de submissão de um objeto `route`):**

A requisição deve conter o objeto RPSL completo em formato de texto.

```http
POST /v1/submit HTTP/1.1
Host: bgp.net.br
Content-Type: text/plain

route: 192.0.2.0/24
descr: Rota de Teste para o Cliente X
origin: AS65000
mnt-by: MAINT-CLIENTEX
source: BGPBR
```

**Observação:** A submissão via API REST geralmente requer autenticação (e-mail/senha ou chave de API) e a sintaxe do objeto RPSL deve ser estritamente seguida. O componente React precisará de um formulário para construir esse objeto RPSL e uma forma de enviar as credenciais de autenticação (que devem ser configuradas de forma segura, possivelmente via variáveis de ambiente do NetBox Ops Center).

## 3. Estrutura do Módulo no Projeto `netbox-ops-center`

O novo módulo será implementado como um conjunto de componentes React/TypeScript dentro da estrutura `src/` do projeto.

| Caminho Sugerido | Descrição |
| :--- | :--- |
| `src/modules/OpsCenterModule/` | Diretório raiz do novo módulo. |
| `src/modules/OpsCenterModule/LookingGlass.tsx` | Componente principal para a funcionalidade de Looking Glass. |
| `src/modules/OpsCenterModule/IRRManager.tsx` | Componente principal para a funcionalidade de Gerenciamento de IRR (Consulta e Manutenção). |
| `src/modules/OpsCenterModule/api.ts` | Funções TypeScript para encapsular as chamadas às APIs (RIPEstat e bgp.net.br). |
| `src/modules/OpsCenterModule/types.ts` | Definições de tipos TypeScript para as estruturas de dados (interfaces). |

A integração final envolverá a adição de uma nova rota no arquivo de roteamento principal do projeto (provavelmente em `src/App.tsx` ou similar) e a inclusão de um link de navegação (menu lateral ou superior).

---
*Fim da Pesquisa Detalhada de Endpoints e Estrutura de Dados.*
